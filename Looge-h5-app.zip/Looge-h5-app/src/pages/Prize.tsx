import React from 'react';

const Prize: React.FC = () => {
    return (
        <div>
            <h1>中奖信息</h1>
            <p>恭喜您获得了奖品！请填写您的领取信息。</p>
            {/* 这里可以添加表单或其他组件来处理奖品领取 */}
        </div>
    );
};

export default Prize;