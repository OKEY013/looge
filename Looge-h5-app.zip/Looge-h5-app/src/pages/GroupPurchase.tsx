import React from 'react';

const GroupPurchase: React.FC = () => {
    return (
        <div>
            <h1>拼团活动</h1>
            <p>这里展示拼团活动的详细信息和参与方式。</p>
            {/* 这里可以添加更多的拼团活动信息和参与按钮 */}
        </div>
    );
};

export default GroupPurchase;