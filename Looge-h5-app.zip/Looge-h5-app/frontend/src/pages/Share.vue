<template>
  <div class="share-container">
    <h2>{{ t('share') }}</h2>
    <div class="invite-info">
      <p>{{ t('invite') }}：<strong>{{ inviteCode }}</strong></p>
      <input class="inviteLink" :value="inviteLink" readonly />
      <button @click="copyLink">{{ t('copyLink') }}</button>
    </div>

    <div class="qrcode-section">
      <canvas ref="qrCanvas"></canvas>
    </div>

    <div class="ad-section">
      <p>{{ adText }}</p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()
const inviteCode = ref('123456')
const inviteLink = `https://looge.com/register?invite=${inviteCode.value}`
const adText = ref('加入Looge幸运团购，拼团抽奖，赢大奖，邀请好友一起参与更有分红！')
const qrCanvas = ref(null)

function copyLink() {
  navigator.clipboard.writeText(inviteLink)
  alert(t('linkCopied'))
}

onMounted(() => {
  import('qrcode').then(QRCode => {
    if (qrCanvas.value && QRCode.toCanvas) {
      QRCode.toCanvas(qrCanvas.value, inviteLink)
    }
  })
})
</script>

<style scoped>
.share-container { max-width:720px; margin:2rem auto; padding:1rem; background:#fff; border-radius:8px }
.invite-info { display:flex; gap:.5rem; align-items:center }
.inviteLink { flex:1; padding:.4rem; border:1px solid #ddd; border-radius:4px }
.qrcode-section { margin-top:1rem }
.ad-section { margin-top:1rem; color:#666 }
button { padding:.4rem .8rem; background:#2196f3; color:#fff; border:none; border-radius:4px }
</style>
